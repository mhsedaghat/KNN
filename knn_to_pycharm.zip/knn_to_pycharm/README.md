# knninpython

This content is the source code for KNN in Python 
